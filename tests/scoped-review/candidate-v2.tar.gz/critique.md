# Critique Methodology

Surface interface quality concerns. Works on anything: code, screenshots, specs, plans.

**Reference files:**

- [checklists.md](references/checklists.md) — Technical checks (states, accessibility, visual coherence, mobile, red flags)
- [interaction.md](references/interaction.md) — Principles of Interface Quality

---

## Detect Input Type

**Artifact** (code, screenshot) → Critique what exists. Output: findings, opportunities.

**Spec/Plan** (feature description, Claude Code plan, PRD, user story) → Surface what's unaddressed. Output: questions, gaps.

The principles and lenses apply to both. The output format adapts.

Keep agent-initiated extra review passes proportional to the task. Run review skills the user explicitly requests, even when their fit is not obvious; do not substitute your preferred tool. Structural or meaning changes may warrant a final voice check without making every critique a fixed chain of skills.

Calibrate length to input. The full format applies to full artifacts. A screen, a flow, a page. For a single component or a narrow question ("thoughts on this button?"), collapse to what's useful: First Impressions + relevant lens + Top Opportunity. The structure scales down. A 1500-word critique on a 200-pixel button is its own kind of bad design.

---

## Input Modes

**Screenshot:** View the image, critique what you see.

**Code:** Read files, mentally render the interface. Focus on what's inferrable: structure, spacing, color, typography, hierarchy, component organization, interaction patterns.

**Both:** Cross-reference — "code does X but visually Y"

**Spec/Plan:** Read the description, surface interaction concerns that haven't been addressed.

---

## Critique Process

### Step 0: Orient

Before any findings, establish:

- **What stage is this?** Exploration, in-flight, production-close, shipped. Calibrate depth to stage — type scale on a wireframe is wasted breath, and flagging a placeholder as a shipped bug is worse.
- **What's already in motion?** Work in progress, known gaps the team is filling, parts of the flow hidden behind flags. Don't flag what's being actively replaced.
- **What's intentional that might look like a gap?** Cold opens, held-back features, missing onboarding moments — some of these are choices, not oversights. Ask before assuming.
- **What is this?** App type, screen purpose, target user.
- **What job is this interface hired to do?** What outcome is the user seeking? (Not feature — outcome.)
- **What state is the user likely in?** Rushed, bored, anxious, skimming, committing. Say it like a person would.
- **What does getting this wrong cost?** Dollars, time, trust, safety, reputation. Every finding below should respect this.

**If stage and in-flight context aren't clear from the prompt, ask.** Two or three quick questions up front save a critique that reads as out of touch.

**Carry this through:** Every finding considers whether the interface respects or ignores the user's likely state, whether it enables the job they came to do, and whether the cost of getting it wrong is legible in the interface.

**Confirm what the screen can't show you:**

Static screens lie by omission. Before making factual claims about behavior, ask — or default to conditional framing:

- Is there a defined brand color or design token system? (Prevents false "color fragmentation" findings.)
- Does this autosave or preserve state across navigation? (Prevents false "no save" findings.)
- Are there keyboard shortcuts, gestures, or interactions not visible here? (Prevents false "no escape" findings.)
- What's not on this screen that's part of the flow? (Prevents false "dead end" findings.)

If answers unknown: hedge. *"If this doesn't autosave, that's a Persistence gap"* lands; *"This doesn't autosave"* overclaims.

**Placeholder, hidden, and in-flight code cannot produce findings.** A `Math.random()` that's actively being replaced is not a Transparency issue. An emoji logo on a feature-flagged screen is not a Craft issue. These belong in a quick "worth confirming is getting cleaned up" note at most, not in the critique body. A finding names user-visible pain in what would ship today — not pain inferred from code that won't.

**Critique like a staff designer. Ask when you don't have context.**

Don't pre-soften, but don't flag a pattern as a problem when it might be intentional. An overconfident finding on a design decision sends the reader down a wrong fix.

- Concrete bug (broken state, wrong copy, measurable failure, typo) — write it. Direct. Explain the why in plain language — don't assume "measure" or "signal" are shared vocabulary.
- Pattern that could be a choice (icon style, card weighting, flow order, skip behavior, forced selection) — ask first. One question resolves it. "Are those category icons the shipping set, or placeholders?" "Is the forced selection the product ask?" Beats a paragraph of assumed criticism.
- Already answered in Step 0 — trust it. Don't re-flag what the user told you is intentional.

The review should match the quality of the work. Clean screen, short review. Broken screen, long review. Don't pad lenses with nothing real.

### Step 1: First Impressions

One paragraph. Gut reaction. What's the immediate emotional response this creates? Does it feel overwhelming, uncertain, confident, cluttered, calm? What stands out? What feels off? Be direct.

---

## The Lenses

These are ways of seeing, not boxes to check. Hold each lens up to the interface and notice what it reveals. Not every lens applies to every interface — use judgment.

**Match length to what's real.** If a lens has something off, write it. If a lens is working, say what's working in a sentence or two — "the hierarchy holds cleanly across the step, and the eye lands on the title before the grid without competition." Specific praise is useful; it tells the reader what to keep. If a lens truly has nothing to say (doesn't apply to this interface, no signal either way), skip it. The fail mode is padding a clean screen with manufactured concerns until it reads as broken.

### General

For a layout-stability issue, inspect the relevant state changes and conditional rows before attributing a height change to text wrapping. Compare representative rendered states when available. A screenshot alone cannot establish which content mounts or disappears. For a contested gap or size, separate occupied content, reserved slots and flexible space; explain what can actually move before proposing a change.

Start with the basics. Is every element earning its place? Anything that doesn't serve the user's goal is stealing attention from what does. Look for paper cuts — the small irritations that compound: empty space while loading, inconsistent hover states, missing placeholders, spacing that shifts between screens. Then stress-test mentally: what happens with twice the content? Half the content? Longer names? The edge cases reveal whether this was designed or just arranged.

### Visual Composition

Look at the interface as a composition, not a collection of items.

**Color.** Identify each color's role and whether the visual weight matches it. Review semantic colors at actual component size and across the supported palettes and relevant states before prescribing a global change. A small accent can behave differently as a large filled button. Preserve intentional palette variation; a color count or decorative use alone does not establish a problem.

**Type.** List the sizes and weights you see. A clear scale has distinct levels — you can point to the headline, the body, the metadata, the labels. A muddy scale has sizes so close they compete rather than complement. Look for one hero size that establishes importance. If everything's shouting, nothing is. The type stack is the skeleton of hierarchy; if it's not working, nothing else will save it.

**Depth.** Do borders, shadows and surface tints communicate a coherent hierarchy? Different treatments may serve different roles, such as bordered panels and a floating popover. Flag a mismatch when it obscures grouping, layering or interaction; mixing techniques alone is not a defect.

**Weight.** The heaviest visual elements — boldest color, largest type, strongest contrast — should match the most important content. This is where intention becomes visible. When a decorative gradient carries more visual weight than the primary action, the hierarchy is lying. Squint at the screen: does importance survive the blur?

### Interface Composition

Now look at the interface as a system of attention and flow.

**Entry point.** Where does your eye land first? There should be ONE clear answer. If attention bounces between the hero, the sidebar, the nav badges, and an inline CTA, nothing has claimed priority. The best interfaces are ruthless about this. Pick one reference this interface should sit next to — then describe what that reference does that this one doesn't.

**Density.** Is the amount of information appropriate for the context? A dashboard used daily can be dense — the user builds fluency. An onboarding screen should breathe — the user is orienting. Settings visited monthly should show the common case and hide the advanced. Density isn't good or bad; it's appropriate or not. Match it to expertise level and task frequency.

**Sequence.** If this takes more than one glance, what order do elements reveal themselves? A clear visual path guides the eye: headline → supporting text → action. A muddy path leaves the user to figure out the reading order on their own. Look at how groupings work — do they guide the sequence or interrupt it? Proximity and whitespace are doing choreography whether you intended it or not.

**Dead ends.** Are there elements that don't lead anywhere? Cards with no action, sections that exist but serve no purpose, information displayed with no next step. These are visual cul-de-sacs. Good interfaces always offer progressive disclosure — there's always somewhere to go next. If a user's attention lands on something, it should reward that attention.

### Interaction

This is where the interface becomes a conversation. Does it help the user do their job, or does it make them work around it? Does it speak their language or system language? Can they tell what's clickable? Do they know what state they're in?

**The Principles.** These are principles to hold while looking, not boxes to check. See [interaction.md](references/interaction.md) for the full framework. The short version:

- **Reversibility** — Can I undo what I just did? Confident users are users who can recover from mistakes.
- **Forgiveness** — Does it prevent errors before they happen? A disabled button during submission, a confirmation before delete.
- **Persistence** — Does my work survive? Refresh, navigation, network failure, closing the tab. Lost work is the deepest betrayal.
- **Transparency** — Do I know what's happening? Loading states, success confirmations, error explanations. Silent interfaces breed anxiety.
- **Escape** — Can I get out? Close the modal, cancel the flow, go back. Trapped users become angry users.
- **Consistency** — Does the same action work the same way everywhere? Or do patterns shift without reason?
- **Craft** — Are these intentional choices or unexamined defaults?
- **Recognition** — Are options visible, or do I have to remember them?

Not every principle applies to every interface. A static marketing page doesn't need Persistence. A checkout flow needs all of them. Use judgment — name the principle only when it's doing real work in the finding. Forcing a line per principle is how the critique turns to filler.

**Motion.** If there's animation, is it earning its place? Motion should clarify, not decorate. And users should never wait for an animation to finish before they can act.

### Craft & Technical

The details that separate "it works" from "someone cared." States, accessibility, polish — the craft layer beneath the design, plus the paper cuts that add up to an unfinished feel.

**Typography.** Read `references/typography.md` and apply the four-job framework inline:
- Orient: what context type is this? What's the primary reading task? Does the font fit the product's personality?
- Count: distinct sizes, weights, colors
- Audit each job (Hierarchy, Rhythm, Measure, Signal) — visual impression first, code flags after

Integrate typography findings into the Craft section prose. For a formal standalone type audit, that's `/typeset`.

For detailed technical checks, reference [checklists.md](references/checklists.md). The checklist covers interaction states (all five: default, hover, active, focus, disabled), data states (loading, empty, error), accessibility (keyboard navigation, focus visibility, semantics, contrast), motion constraints, and mobile considerations.

The craft lens isn't about checking boxes — it's about noticing whether the interface feels finished or feels like a prototype that shipped too early.

### Consistency

Does the interface feel like one designer made it, or like it was assembled from different kits?

When adopting a component library into an existing product, inventory the real controls, required states and visual language first. Keep useful shared behavior while adapting defaults. Additional variants should serve existing needs or the approved brief; a library's full catalog is not itself a product requirement.

**Pattern consistency.** Are similar actions handled the same way throughout? Delete works like delete everywhere? Modals all close the same way? When patterns shift without reason, users lose trust — they can't predict what will happen next.

**Platform conventions.** Does it follow established patterns for its platform — iOS, Android, web? Deviations aren't wrong, but they should be intentional improvements, not accidents. Users carry expectations from every other app they use.

**Component reuse.** Look for elements that should be the same component but aren't. Two card styles that are almost identical. Buttons that look different in different contexts. List items that change treatment between screens. These inconsistencies signal "no system."

**Visual language cohesion.** Step back and ask: does this feel unified? Same voice, same hand, same intention throughout? Or does it feel like three different designers worked on it without talking?

### Flow Coherence

_This lens applies when reviewing multiple screens or a sequence._

For an embedded demo, inspect both the demo at a readable scale and its placement in the host page at relevant supported widths. Check surrounding navigation, nested scrolling and reachability. Name missing visual evidence when only source or one capture is available; do not claim the other scale was verified.

For a portfolio flow, identify each screen's job, product decision and supporting evidence for the agreed audience before polishing the sequence. Preserve useful breadth. Do not infer authorship or shipped status from the pixels, or force a fixed set of career roles onto the work.

Flows have their own logic. Do the screens connect naturally — is the path obvious, or does the user have to figure out where they are? Does data persist across steps, or do they re-enter information? Do they know where they are in the process (step 2 of 4) and how much is left?

Look for escape routes. Can they abandon the flow at any point? Go back? What happens if something fails mid-flow — can they resume, or do they start over? What happens on refresh — does the URL deep-link to step 3, or does it dump them back at the beginning?

Good flows tell a story. There's a beginning (orientation), a middle (the work), and an end (completion, reward). Bad flows feel like a series of screens that happen to be connected.

---

## Output Format

```markdown
## Context

[1-2 sentences on what this is and who it's for. Name the stage (exploration / in-flight / production-close / shipped) and anything known to be in motion. Name the user's state in one human sentence (rushed, anxious, skimming, committing). Name what getting this wrong costs — dollars, time, trust, safety, reputation. The cost line grounds every finding below.]

## First Impressions

[1 paragraph. Gut reaction. What's the overall impression? Name the emotion the interface creates — not just "good" or "confusing" but the specific feeling: "quiet confidence," "overwhelming density," "polished but cold." What stands out? What feels off? Be direct and honest, not tentative. Describe the screen to someone who can't see it. The description is the critique. Before judgment, inventory.]

## Findings

Write each section as narrative prose with bolded issue names, not bulleted checklists. Lead with observation, then impact, then opportunity.

### Visual Composition

[Color, type, depth, weight distribution — analyzed as a composition, not a list of items. What's the color story? How does the type scale create hierarchy? Is there one depth strategy or several competing?]

### Interface Composition

[Entry point, density, sequence, dead ends. Where does the eye land? Is complexity revealed gradually? Are there visual cul-de-sacs? Do the same entities appear in multiple places with different mental models?]

### Interaction

[The principles that actually matter for this interface. Name the principle in the finding when it earns the line — "Reversibility is the quiet strength here: the destructive actions all confirm, and undo is one step away." Skip principles that don't apply or don't have anything to say.]

### Craft

[States, accessibility, polish. The details that separate "it works" from "someone cared." Paper cuts — the small compounding issues (hover inconsistencies, redundant captions, UI debris) — live here.]

### Consistency

[Pattern consistency, platform conventions, component reuse, visual cohesion. Does it feel like one designer made this, or like it was assembled from different kits?]

## User Context

[Return to empathy. Answer these in prose, not bullets:]

- How does this interface make the user feel? Name the emotion precisely.
- What is the user's likely state of mind coming into this?
- Does the interface respect or ignore that state?
- Is the cost of getting this wrong visible enough to the user?

## Top Opportunities

[Highest-impact changes, framed as openings. Each in one sentence, tied to affected principles where relevant. As many as are real — one is fine if one is the real answer, five if there are five. Don't pad to hit a count.]

## Where this could go next

[Optional. Include only when useful product directions fit the requested scope and the evidence. Omit when none add value. Do not manufacture a direction or reopen settled product choices to fill this section.]

[Include file:line for code issues where relevant]
```

---

## Finding Format

Frame findings either as:

- **[Issue name]** — What's there. What it costs. What's better.
- **Opening:** [What could be better]. [What's there now]. [The gap].

Prefer door-opening framing. A finding framed as an opening invites action; a finding framed as a gap just documents one. "There's a reward moment waiting here" gets built; "progress feedback is missing" gets filed.

---

## On asserting absence

The skill can only see what's in the pixels. When a claim requires knowing something offscreen — autosave, brand system, keyboard shortcuts, parts of the flow not rendered here — frame the finding conditionally, not as fact.

✅ *"If this doesn't autosave, that's a Persistence gap."* — invites verification
❌ *"This doesn't autosave."* — overclaims from a static image

✅ *"If purple isn't a defined brand color, nine uses is fragmentation."* — respects possible intent
❌ *"Purple is monoculture."* — ignores brand-system reality

The first lands as a question worth answering. The second overclaims. When uncertain, hedge explicitly — Step 0 should have confirmed these where possible, but if it didn't, the finding itself names the conditional.

This matters for severity too. A finding that claims user pain should be able to name where and how. If the pain is inferred from code that won't ship, the finding belongs in the in-flight note, not in the critique body.

---

## Voice

Follow the voice guidelines in [SKILL.md](SKILL.md#voice).

---

## For Specs & Plans

When the input is a spec, plan, or feature description (not an artifact), shift from critique to question-surfacing.

### Intent Questions (ask first)

Before interaction questions, establish intent:

- **Who is this human?** Not "users." The actual person. Where are they when they open this? What's on their mind?
- **What must they accomplish?** Not "use the feature." The verb. What action, what outcome?
- **What should this feel like?** Say it in words that mean something. "Clean and modern" means nothing. Warm like a notebook? Cold like a terminal? Dense like a trading floor? Calm like a reading app?

If the spec doesn't answer these with specifics, ask.

### Craft Questions

These decisions shape everything downstream. Surface them early:

- **Depth strategy:** How should borders, shadows or surface shifts communicate grouping and layering? Mixed treatments can be coherent when they have distinct roles.
- **Typography:** What typeface fits the feel? Don't default — select.
- **Color temperature:** Warm, cool, neutral? What colors exist in this product's world?
- **Information density:** Spacious or dense? What serves the user's task?

### Interaction Questions

Work through each principle. Surface what's unaddressed:

**Reversibility:** Can users recover from mistakes? Undo, trash, version history?

**Forgiveness:** What happens on double-click? Bad input? Are destructive actions distinguishable from safe ones?

**Persistence:** What survives refresh? Navigation? API failure? Is there autosave?

**Transparency:** How will they know it worked? What does loading look like? What do errors show?

**Escape:** Can they cancel at any point? Close modals? Go back in flows?

**Consistency:** Does this work like similar actions elsewhere in the app? Platform conventions?

**Recognition:** Are options visible or must they remember them?

### Output Format for Specs

```markdown
## [Feature Name]

### Questions

**Intent:**

- [Questions about who/what/feel if unclear]

**Craft:**

- [Decisions that need to be made early]

**Interaction:**

**Reversibility:**

- [Questions about recovery]

**Persistence:**

- [Questions about state survival]

[...etc, only principles that apply]

### Suggestions

[If you have enough context to suggest answers, offer them as defaults to accept or override]
```

---

## Severity

Order findings by impact:

1. **Structural** — Information architecture, missing functionality, wrong mental model
2. **Behavioral** — How interface responds, flows, communicates
3. **Visual** — Color, type, spacing, shadows

Structural > Behavioral > Visual.

---

## Examples

**Visual Composition:**

> **Fragmented color story** — 14 distinct uses of purple across the page: navigation icons, card borders, badges, text highlights, gradients. Purple has become noise instead of signal. When everything is emphasized, nothing is. Pick 2-3 intentional uses and retire the rest.

**Interface Composition:**

> **No entry point** — Hero, sidebar promo, navigation badges, and inline CTA all compete at roughly equal visual weight. Nothing has claimed priority — attention has to pick a target. The hero is theoretically the entry, but the animated sidebar pulls just as hard. Pick one focal point and subordinate everything else.

**Density:**

> **Dashboard dense, user casual** — This is a settings page users visit once a month, but it's laid out like a trading terminal. 40+ controls visible at once. A monthly visitor needs progressive disclosure — show the common case, reveal advanced on demand.

**Emotional mismatch:**

> **Checkout anxiety ignored** — User is about to spend money. The interface shows a wall of small text, multiple upsells, and a "Place Order" button that's the same size as secondary actions. This is the moment for confidence and focus. Strip everything that isn't "here's what you're getting, here's what you're paying, here's how to complete." The user's anxiety is a design constraint.

**Interaction:**

> **Silent submit** — Button says "Save" but gives no feedback on click. User doesn't know if it worked. Add loading state during async, success confirmation after.

**Flow:**

> **Lost context on back** — User fills shipping address (step 2), clicks back to cart (step 1), returns — address fields empty. State not persisted across navigation.

**Paper cut:**

> **Hover inconsistency** — Primary buttons have hover states. Secondary buttons don't. Table rows are hoverable but don't show it until clicked. Small, but these add up to "unfinished."

**Consistency:**

> **Interaction patterns shift** — Primary actions use filled buttons, except on the settings page where they're outlined. Modals close with X in the corner, except the confirmation dialog which only has "Cancel" and "Confirm" buttons. Each inconsistency is small, but together they signal "assembled, not designed."

**User Context:**

> **How does this make the user feel?** Respect, but not excitement. There's no anxiety, no confusion — but also no pull. The interface is _correct_ without being _magnetic_.
>
> **What state are they in?** Evaluative. Scanning many portfolios, skeptical by default, ready to bounce. Looking for signal.
>
> **Does the interface respect that state?** It respects their time — scannable, fast, no friction. But it doesn't reward curiosity. For a portfolio where the goal is to make someone want to learn more, "calm competence" might not be enough. The user needs a reason to click.

**Where this could go next:**

> The form validation works. If I had one more day on this, here's where I'd take it:
>
> - A subtle progress indicator that grows as the form fills — the form stops feeling like a blocker and starts feeling like momentum
> - Smart defaults pre-filled from context or prior entries — the form does work *for* the user instead of asking them to do work
>
> Small moves. But they shift the form from "functional" to "someone thought about me" — which is also what separates a task from a product.
